create function pg_sleep_for(interval) returns void
    strict
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.pg_sleep(extract(epoch from pg_catalog.clock_timestamp() operator(pg_catalog.+) $1) operator(pg_catalog.-) extract(epoch from pg_catalog.clock_timestamp()))$$;

comment on function pg_sleep_for(interval) is 'sleep for the specified interval';

alter function pg_sleep_for(interval) owner to postgres;

