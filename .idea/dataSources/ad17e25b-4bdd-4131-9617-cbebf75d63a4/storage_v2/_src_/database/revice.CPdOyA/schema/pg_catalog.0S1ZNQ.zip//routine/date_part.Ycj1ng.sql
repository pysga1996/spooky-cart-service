create function date_part(text, date) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function date_part(text, timestamp with time zone) is 'extract field from timestamp with time zone';

alter function date_part(text, timestamp with time zone) owner to postgres;

